﻿using MailKit.Net.Imap;
using MailKit.Net.Pop3;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MariaDb_WPF
{
    public class Reader
    {
        public static MContext context = new MContext();
        
        public static int ReadUnOpenedEmails()
        {
            
            using (var client = new Pop3Client())
            {
                int mails = 0;
                client.ServerCertificateValidationCallback = (s, c, h, e) => true;
                client.SslProtocols = System.Security.Authentication.SslProtocols.Tls12;
                client.Connect("pop.gmail.com", 995, true);
                client.AuthenticationMechanisms.Remove("XOAUTH2");
                client.Authenticate(Global.myEmail, Global.myEmailPassword);

                DateTime latestUpdate = Convert.ToDateTime(Helper.GetLatestUpdate(context));
                for (int i = 0; i < client.Count; i++)
                {
                    var message = client.GetMessage(i);
                    var subjet = message.Subject;
                    var body = message.GetTextBody(MimeKit.Text.TextFormat.Text);
                        string[] Data = body.Split("\"");
                        foreach (var item in Data)
                        {
                            {
                                try
                                {
                                    var date = Convert.ToDateTime(item);
                                    if(date > latestUpdate)
                                    {
                                        CreateCommand(body);
                                        mails++;
                                    }
                                }
                                catch (Exception)
                                {
                                    continue;
                                }
                            }
                        }
                }
                return mails;
            }
        }
        private static void CreateCommand(string queryString)
        {
            string connectionString = "server=localhost;User Id=root;Password=Hejsan123!;database=gnu;";
            using MySqlConnection conn = new MySqlConnection(connectionString);
            {
                MySqlCommand comm = conn.CreateCommand();
                {
                    conn.Open();
                    comm.CommandText = queryString;
                    comm.ExecuteNonQuery();
                }
                
            }
        }
    }
}
