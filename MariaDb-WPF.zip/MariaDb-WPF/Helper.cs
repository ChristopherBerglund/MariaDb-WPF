﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MariaDb_WPF
{
    public class Helper
    {

        public static string GetLatestUpdate(MContext context)
        {
            var latestPost = context.Posts.OrderByDescending(x => x.DateTime).ToList();
            var latestComments = context.Comments.OrderByDescending(x => x.date).ToList();
            var latestDiscussion = context.Discussion.OrderByDescending(x => x.createddate).ToList();
            DateTime latestCom = Convert.ToDateTime(latestComments[0].date);
            DateTime latestDis = Convert.ToDateTime(latestPost[0].DateTime);
            DateTime latestPos = Convert.ToDateTime(latestDiscussion[0].createddate);

            List<DateTime> alltime = new List<DateTime>() { latestCom, latestDis, latestPos };
            alltime.OrderByDescending(x => x).ToList();
            DateTime latestUpdate = alltime[0];
            return latestUpdate.ToString();
        }
        
    }
}
