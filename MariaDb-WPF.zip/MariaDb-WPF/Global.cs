﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MariaDb_WPF
{
    public class Global
    {
        public static string myEmail;
        public static string myEmailPassword;

        //public static string myEmail = "bobertestar@gmail.com";
        //public static string myEmailPassword = "twlmqwaalsbdogbi";
        //public static string myUserName = "chris";
        //public static string ConnectionString = "server=localhost;User Id=root;Password=Hejsan123!;database=gnu;";
    }
}
